package net.sourceforge.jFuzzyLogic;

/**
 * Author's data
 * @author pcingola
 */
public class Pcingola {

	public static final String EMAIL = "pablo.e.cingolani@gmail.com";
	public static final String BY = "Pablo Cingolani";
}
