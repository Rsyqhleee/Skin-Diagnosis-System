/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.sourceforge.jFuzzyLogic.demo.dynamics;

/**
 *
 * @author pjl
 */
public interface ForceDrivenModel {

    public void setForce(double f);

}
