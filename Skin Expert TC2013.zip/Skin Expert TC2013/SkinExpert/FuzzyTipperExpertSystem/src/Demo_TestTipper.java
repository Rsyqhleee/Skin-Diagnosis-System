


import net.sourceforge.jFuzzyLogic.FIS;
import net.sourceforge.jFuzzyLogic.FunctionBlock;
import net.sourceforge.jFuzzyLogic.Gpr;
import net.sourceforge.jFuzzyLogic.plot.JFuzzyChart;
import net.sourceforge.jFuzzyLogic.rule.Variable;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Farah
 */
//https://www.programcreek.com/java-api-examples/index.php?api=net.sourceforge.jFuzzyLogic.plot.JFuzzyChart
public class Demo_TestTipper {
    
    
    public static void main(String[] args)  {
	// Load from 'FCL' file
//	String fileName = "fcl/tipper.fcl";
    //  String fileName ="C:/Users/Farah/Documents/NetBeansProjects/FuzzyLogic/src/fcl/tipper.fcl" ;
    	String fileName ="G:/My Drive/kuliah/TC2243 Knowledge Based System/KBS/Lab_KBS/src-FuzzyLogic/src/fcl/tipper.fcl";
	FIS fis = FIS.load(fileName, true);
	if (fis == null) { // Error while loading?
		System.err.println("Can't load file: '" + fileName + "'");
		return;
	}

	// Show ruleset
	FunctionBlock functionBlock = fis.getFunctionBlock(null);
	JFuzzyChart.get().chart(functionBlock);

	// Set inputs
	functionBlock.setVariable("service", 3);
//	functionBlock.setVariable("food", 7);
        functionBlock.setVariable("food", 8);

	// Evaluate 
	functionBlock.evaluate();

	// Show output variable's chart
	Variable tip = functionBlock.getVariable("tip");
	JFuzzyChart.get().chart(tip, tip.getDefuzzifier(), true);
	Gpr.debug("poor[service]: " + functionBlock.getVariable("service").getMembership("poor"));

	// Print ruleSet
	System.out.println(functionBlock);
	System.out.println("TIP:" + functionBlock.getVariable("tip").getValue());
    }   
}
