import net.sourceforge.jFuzzyLogic.FIS;
import net.sourceforge.jFuzzyLogic.FunctionBlock;
import net.sourceforge.jFuzzyLogic.Gpr;
import net.sourceforge.jFuzzyLogic.plot.JFuzzyChart;
import net.sourceforge.jFuzzyLogic.rule.Variable;

public class SkinExpert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	System.out.println("This is Skin Expert System");
    // Load from 'FCL' file
    String fileName = "C:/Users/User/Desktop/SkinExpert/FuzzyTipperExpertSystem/src/fcl/skinexpert.fcl";
    FIS fis = FIS.load(fileName, true);
	if (fis == null) { // Error while loading?
		System.err.println("Can't load file: '" + fileName + "'");
		return;
	}

	// Show ruleset
	FunctionBlock functionBlock = fis.getFunctionBlock(null);
	JFuzzyChart.get().chart(functionBlock);

	// Set inputs
		functionBlock.setVariable("appearance", 5);
        functionBlock.setVariable("texture", 7);
        functionBlock.setVariable("blemish", 3);
        functionBlock.setVariable("irritation", 3);
        functionBlock.setVariable("pores", 2);
        
	// Evaluate 
	functionBlock.evaluate();

	// Show output variable's chart
	Variable skintype = functionBlock.getVariable("skintype");
	JFuzzyChart.get().chart(skintype, skintype.getDefuzzifier(), true);
	Gpr.debug("skintype[combination]: " + functionBlock.getVariable("skintype").getMembership("combination"));

	// Print ruleSet
	System.out.println(functionBlock);
	System.out.println("SKIN TYPE:" + functionBlock.getVariable("skintype").getValue());

	
	
	}

}

