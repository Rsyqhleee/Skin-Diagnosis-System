/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//Given input: -url=google.com,-time=5,-email=asdfg@hotmail.com
package ExParsingInput;

  //package url.checker;

    import java.util.Scanner;

        public class Main {

          public static void main(String[] args) 
          {


            Scanner in = new Scanner(System.in);
            System.out.println("Enter the integer");
////            Parse.s = in.nextLine();
////            Parse.GetInput(Parse.s);
                Parse.GetInput(in.nextLine());//panggil class dan function lain
          }
   }   