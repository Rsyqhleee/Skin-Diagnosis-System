
import net.sourceforge.jFuzzyLogic.FIS;
import net.sourceforge.jFuzzyLogic.FunctionBlock;
import net.sourceforge.jFuzzyLogic.plot.JFuzzyChart;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Farah
 */

//Fuzzy Control Langage FCL is defined by IEC 1331 part 7. 
//It's a simple language to define a fuzzy inferece system. 
//We'll take a look at an example, for a more detailed explanation, please read the spec.

public class Demo_FuzzyTest {
    
    public static void main(String[] args) {
    // Load from 'FCL' file
//    String fileName = "fcl/Blob.fcl";
//    String fileName ="C:/Users/Farah/Documents/NetBeansProjects/FuzzyLogic/src/fcl/block.fcl" ;
    String fileName = "G:/My Drive/kuliah/TC2243 Knowledge Based System/KBS/Lab_KBS/src-FuzzyLogic/src/fcl/block.fcl";
    FIS fis = FIS.load(fileName, true);

    if (fis == null) {
        System.err.println("Can't load file: '" + fileName + "'");
        System.exit(1);
    }

    // Get default function block
    FunctionBlock fb = fis.getFunctionBlock(null);
    JFuzzyChart.get().chart(fb);
    int [] lcom = {26,27,27,28,60,320,26,39}; // 25,40
    int [] nom = {17,17,18,19,17,21,27,22}; // 14.5,22
    int [] noa = {9,9,10,10,17,10,13,13}; // 8.5,13
    JFuzzyChart.get().chart(fb);
    for (int i = 0; i< lcom.length;i++){
        fb.setVariable("lack_of_cohesion_in_methods", lcom[i]);
        fb.setVariable("number_of_methods", nom[i]);
        fb.setVariable("number_of_attributes", noa[i]);
        fb.evaluate();
        JFuzzyChart.get().chart(fb.getVariable("res"),fb.getVariable("res").getDefuzzifier(),true);
        System.out.println("Res ("+lcom[i]+","+nom[i]+","+noa[i]+"): " + fb.getVariable("res").getValue());
    }
}
 
    
    
}
