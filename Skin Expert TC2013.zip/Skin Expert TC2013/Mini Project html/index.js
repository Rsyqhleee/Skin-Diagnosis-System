function check() {
    var c=0;
    var skinAppearance=document.cat.q1.value;
    var skinTexture=document.cat.q2.value;
    var BlemishesCondition=document.cat.q3.value;
    var IrritationRate=document.cat.q4.value;
    var PoresCondition=document.cat.q5.value;
    var result=document.getElementById('result');
    var cat=document.getElementById("cat");
    cat.style.display="none";
    
    //RULES
    
    //feline panleukopenia virus
    //1
    if(skinAppearance=="Radiant" || skinAppearance=="Dull" || skinAppearance=="Shiny" && skinTexture=="Normal" && BlemishesCondition=="Nonvisible" && IrritationRate=="Low" || IrritationRate=="Moderate" && PoresCondition=="Shrink" || PoresCondition=="Enlarge"){
     result.textContent='Your skintype IS normal!';
    }
    
    //2
    if(skinAppearance=="Radiant" || skinAppearance=="Dull" && skinTexture=="Normal" || skinTexture=="Greasy" || skinTexture=="Rough" && BlemishesCondition=="Nonvisible" || BlemishesCondition=="Visible" && IrritationRate=="Low" || IrritationRate=="Moderate" || IrritationRate=="High" && PoresCondition=="Shrink" || PoresCondition=="Enlarge"){
     result.textContent='Your skintype IS dry!';
    }
    
    //3
    if(skinAppearance=="Radiant" || skinAppearance=="Shiny" && skinTexture=="Greasy" || skinTexture=="Rough" && BlemishesCondition=="Nonvisible" || BlemishesCondition=="Visible" && IrritationRate=="Low" || IrritationRate=="Moderate" || IrritationRate=="High" && PoresCondition=="Enlarge"){
     result.textContent='Your skintype IS Oily!';
    }
    
    //4
    if(skinAppearance=="Radiant" || skinAppearance=="Dull" || skinAppearance=="Shiny" && skinTexture=="Normal" || skinTexture=="Greasy" || skinTexture=="Rough" && BlemishesCondition=="Nonvisible" || BlemishesCondition=="Visible" && IrritationRate=="Low" || IrritationRate=="Moderate" || IrritationRate=="High" && PoresCondition=="Enlarge"){
     result.textContent='Your skintype IS combination!';
    }
    
   }
   